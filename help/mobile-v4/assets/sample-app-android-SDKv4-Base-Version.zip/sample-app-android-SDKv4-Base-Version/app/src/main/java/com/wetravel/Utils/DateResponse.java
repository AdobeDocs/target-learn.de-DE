package com.wetravel.Utils;

public interface DateResponse {
    void onDateSelected(String selectedDate, String dayOfWeek);
}
