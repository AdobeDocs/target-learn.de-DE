package com.wetravel.Models;

import java.util.ArrayList;

public class HomeResponse extends BaseModel{
    public ArrayList<Offer> offers;

}
