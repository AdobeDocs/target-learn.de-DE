package com.wetravel.Models;

import java.util.ArrayList;

public class SearchResponse extends BaseModel{
    public ArrayList<Offer> offers;
    public ArrayList<Travel> travel_details;
}
